module.exports = 'hello from @vp-smoke/hello';
