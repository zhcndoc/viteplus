export const name = 'demo';
