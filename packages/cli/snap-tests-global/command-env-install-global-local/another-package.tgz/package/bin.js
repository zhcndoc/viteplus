console.log("Another package is installed successfully");
