# Bundled Monorepo Template

This is a minimal monorepo template shipped via the @your-org/create manifest.
